package Day5Handson.Overriding

class People {
  def detail(): Unit ={
    println("In Person class need gender data")
  }
}
