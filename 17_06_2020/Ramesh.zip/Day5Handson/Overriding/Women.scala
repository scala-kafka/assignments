package Day5Handson.Overriding

class Women extends People{
  override def detail(): Unit ={
    super.detail()
    println("I am in Women")
  }
}
