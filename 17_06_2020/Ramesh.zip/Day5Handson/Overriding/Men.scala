package Day5Handson.Overriding

class Men extends People {
  override def detail(): Unit ={
    super.detail()
    println("I am in Men")
  }
}
