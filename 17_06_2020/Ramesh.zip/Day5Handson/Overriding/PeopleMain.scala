package Day5Handson.Overriding

object PeopleMain {

  def main(args: Array[String]): Unit = {
    println("Calling only the Person class")
    var person:People = new People
    person.detail()

    println("Using the Person class as reference and Men as Object ");
    var men:People = new Men
    men.detail()

    println("Using the Person class as reference and Women as Object ");
    var women:People = new Women
    men.detail()
  }

}
