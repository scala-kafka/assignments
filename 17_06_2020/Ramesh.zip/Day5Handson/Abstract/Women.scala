package Day5Handson.Abstract

class Women extends People{
  override def detail(): Unit ={
    super.god()
    println("I am Women")
  }
}
