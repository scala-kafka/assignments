package Day5Handson.Abstract

object PeopleMain {

  def main(args: Array[String]): Unit = {
    println("Using the Person class as reference and Men as Object ");
    var men:People = new Men
    men.detail()

    println("Using the Person class as reference and Women as Object ");
    var women:People = new Women
    men.detail()
  }

}
