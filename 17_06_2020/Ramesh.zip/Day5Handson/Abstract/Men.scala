package Day5Handson.Abstract

class Men extends People {
  override def detail(): Unit ={
    super.god()
    println("I am Men")
  }
}
