package Day5Handson.Abstract

abstract class People {
  def detail()
  def god(): Unit ={
    println("God I invented you")
  }
}
