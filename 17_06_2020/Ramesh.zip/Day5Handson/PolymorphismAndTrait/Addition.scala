package Day5Handson.PolymorphismAndTrait

class Addition extends PrintData with Starts {

  def calculation(a:Int,b:Int): Unit ={
        super.start()
        var cal = a+b
        println(s"Result = $cal")

  }

}
