package Day5Handson.PolymorphismAndTrait

class Subract extends PrintData  with Starts{

  def calculation(a:Int,b:Int): Unit ={
    var cal = a-b
    println(s"Result = $cal")
    super.print()
  }

}
