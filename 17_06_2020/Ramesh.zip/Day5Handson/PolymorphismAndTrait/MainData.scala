package Day5Handson.PolymorphismAndTrait

object MainData {
  def main(args: Array[String]): Unit = {

    var add:PrintData = new Addition()
    add.calculation(14,20)
    add.print()

    var sub:Starts =new Subract
    sub.start()
    var sub1:PrintData = new Subract
    sub1.calculation(25,74)

    var mul:PrintData = new Multiply
    mul.calculation(7,2)

    var fac:PrintData = new Factor
    fac.calculation(56,12)

  }
}
