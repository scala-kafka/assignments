package Day5Handson.PolymorphismAndTrait

trait Calculate {
  def calculation(x:Int,y:Int)
}

trait Starts {
  def start(): Unit ={
    println("Calculation started")
  }
}

trait PrintData extends Calculate{
  def print(): Unit ={
    println("Calculation Completed")
  }
}
