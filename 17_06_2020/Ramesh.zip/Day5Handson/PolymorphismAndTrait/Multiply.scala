package Day5Handson.PolymorphismAndTrait

class Multiply extends PrintData with Starts{

  def calculation(a:Int,b:Int): Unit ={
    super.start()
    var cal = a*b
    println(s"Result = $cal")
    super.print()
  }

}
