package Day5Handson.InheritanceAss.Ass2

class NonFueledVehicle(id:Int,passengerCapacity:Int) extends  Vehicle(id, passengerCapacity){

}
