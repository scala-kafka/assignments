package Day5Handson.InheritanceAss.Ass2

class Bicycle(id:Int,passengerCapacity:Int,description:String) extends NonFueledVehicle(id, passengerCapacity) {

  def bicycleDetail(): Unit ={
    println("Description :"+description)
  }
}
