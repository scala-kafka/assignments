package Day5Handson.InheritanceAss.Ass2

class Vehicle() {
    var id:Int = _
    var passengerCapacity:Int = _
  def this(id:Int,passengerCapacity:Int){
    this()
    this.id = id
    this.passengerCapacity = passengerCapacity
  }

  def vehicleDetail(): Unit ={
    println("Id :"+id)
    println("PassengerCapacity :"+passengerCapacity)
  }
}
