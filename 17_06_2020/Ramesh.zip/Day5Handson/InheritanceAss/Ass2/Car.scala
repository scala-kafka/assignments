package Day5Handson.InheritanceAss.Ass2

class Car(id:Int,passengerCapacity:Int,fuelCapacity:Int,fuelType:String,description:String)
   extends FueledVehicle(id,passengerCapacity,fuelCapacity ,fuelType ) {
  def CarDetail(): Unit ={
    super.vehicleDetail()
    super.fueledVehicleDetail()
    println("Description :"+description)
  }
}
