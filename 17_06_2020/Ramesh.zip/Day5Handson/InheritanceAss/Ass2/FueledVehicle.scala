package Day5Handson.InheritanceAss.Ass2

class FueledVehicle(id:Int,passengerCapacity:Int,fuelCapacity:Int,fuelType:String) extends  Vehicle(id,passengerCapacity){
  def fueledVehicleDetail(): Unit ={
    println("Fuel Capacity :"+fuelCapacity)
    println("Fuel Type :"+fuelType)
  }
}
