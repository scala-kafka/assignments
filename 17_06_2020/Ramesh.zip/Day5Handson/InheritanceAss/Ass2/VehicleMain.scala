package Day5Handson.InheritanceAss.Ass2

object VehicleMain {
  def main(args: Array[String]): Unit = {

    var car:Car = new Car(17,4,24,"Petrol","I20 Brand")
    car.CarDetail()
    
    var bicycle:Bicycle = new Bicycle(14,2,"Has 3 gears")
    bicycle.vehicleDetail()
    bicycle.bicycleDetail()
  }
}
