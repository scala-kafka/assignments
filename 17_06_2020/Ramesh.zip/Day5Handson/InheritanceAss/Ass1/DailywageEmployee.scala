package Day5Handson.InheritanceAss.Ass1

class DailywageEmployee(eno:Int, name:String, salary:Double) extends Employee (eno, name, salary) {

  override def printDetail(): Unit ={
    println(s"Daily wage Employee Detail\n Number  =  $eno\nName  =  $name\nSalary  =  $salary")
  }

}
