package Day5Handson.InheritanceAss.Ass1

class Employee(eno:Int,name:String,salary:Double) {

  def printDetail(): Unit ={
    println(s"Employee Detail\n Number  =  $eno\nName  =  $name\nSalary  =  $salary")
  }

}
