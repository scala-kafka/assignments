package Day5Handson.InheritanceAss.Ass1

class SalariedEmployee(eno:Int, name:String, salary:Double) extends Employee (eno, name, salary) {

  override def printDetail(): Unit ={
    println(s"Salaried Employee Detail\n Number  =  $eno\nName  =  $name\nSalary  =  $salary")
  }

}
