package Day5Handson.InheritanceAss.Ass1

object EmployeeMain {
  def main(args: Array[String]): Unit = {

    var dailywage:Employee = new DailywageEmployee(12,"Dev",475)
    dailywage.printDetail()

    var salariedEmployee:Employee = new SalariedEmployee(254,"Keert",78541.54)
    salariedEmployee.printDetail()

  }
}
