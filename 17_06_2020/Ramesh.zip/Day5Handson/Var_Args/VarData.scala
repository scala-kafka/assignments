package Day5Handson.Var_Args

class VarData {

  def dataDisplay(x:Int*): Unit ={
    x.foreach(data => print(data +"\t"))
    println()
  }

  def dataDisplay(a:Double,x:Any*): Unit ={
    x.foreach(data => print(data +"\t"))
    println()
  }



}
