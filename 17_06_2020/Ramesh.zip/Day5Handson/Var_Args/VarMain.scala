package Day5Handson.Var_Args

object VarMain {

  def main(args: Array[String]): Unit = {
    var varData:VarData = new VarData

    println("Accept Only Integer")
    varData.dataDisplay(1,5,8,45)

    println("Accept First argument a Double other as Any Type")
    varData.dataDisplay(5.8,"Data",45.8,54)
  }

}
