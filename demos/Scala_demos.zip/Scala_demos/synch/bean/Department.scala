package com.info.synch.bean

case class Department(departmentId:Int,departmentName:String) {
  
}