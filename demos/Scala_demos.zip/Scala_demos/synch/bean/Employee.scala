package com.info.synch.bean

case class Employee(employeeId:Int,employeeName:String) {
  
}