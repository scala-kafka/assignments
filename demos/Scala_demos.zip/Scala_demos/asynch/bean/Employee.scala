package com.info.asynch.bean

case class Employee(employeeId:Int,employeeName:String) {
  
}