package com.info.asynch.bean

case class Department(departmentId:Int,departmentName:String) {
  
}