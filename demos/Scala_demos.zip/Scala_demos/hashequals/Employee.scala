/*
package com.info.hashequals

object Employee {

  def apply(employeeName: String, salary: Double) = {
    new Employee(employeeName, salary)
  }

}

class Employee(employeeName:String, salary:Double){

  // variable
  // getters---setters
  // other methods

}
*/
