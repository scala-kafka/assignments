/*
package com.info.hashequals

import com.info.caseclass
import com.info.caseclass.Employee

object ApplyDemo {

  def main(args: Array[String]): Unit = {

    var emp:caseclass.Employee = new caseclass.Employee("Varun", 56000)

    var Employee(emp2, emp3, emp4) = emp;


  }

}
*/
