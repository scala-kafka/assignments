package Day6Handson.Exception

class Account {

  var employeeNo = 0
  var employeeName: String = null
  var balance = 0.0
  var withdrawAmount = 0.0

  def this(employeeNo: Int, employeeName: String, withdrawAmount: Double) {
    this()
    this.employeeNo = employeeNo
    this.employeeName = employeeName
    this.withdrawAmount = withdrawAmount
  }

  def withdraw(): Unit = {
    balance = 10000
    if ((balance - withdrawAmount) < 3000) {
      val le = new LowBalanceException
      throw le
    }
    else balance -= withdrawAmount
  }

  def printDetail(): Unit = {
    println("employeeNo = " + employeeNo)
    println("employeeName = " + employeeName)
    println("balance = " + (balance - 3000))
  }

}
