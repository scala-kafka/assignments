package Day6Handson.Exception

class LowBalanceException extends Exception{

  override def getMessage() = "You account has LOW BALANCE" ;

}

