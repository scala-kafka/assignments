package Day6Handson.Exception

import java.util.{InputMismatchException, Scanner}

object CutomExceptionMain {
  def main(args: Array[String]): Unit = {
    var ip = new Scanner(System.in);

    try {

      println("Enter amount to withdraw ");
      var withDraw:Int = ip.nextInt();

      var acc:Account = new Account(122,"Kenny",withDraw);
      acc.withdraw();
      acc.printDetail();
    }catch {
      case ime:InputMismatchException => println(" Enter valid withDraw amount  ");
      case lbe:LowBalanceException => println(lbe.getMessage() );
      case  e:Exception =>  println(e.getMessage() );
    }
    finally {
      ip.close();
    }
  }
}
