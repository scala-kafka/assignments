package Day6Handson.Ass

object MapAss {

  def main(args: Array[String]): Unit = {
    var name = Set("Siva","Sree","Sk","Sandy")
    var name2 = Set("Sk","Candy","Mani","Lokesh")

    var concatName = name.concat(name2)
    println("Remove Duplicate of concatName Set  : " +concatName.toString())

    println("Before adding element to Name Set : " + name.toString())
    name += "Karthy"
    println("After adding element to Name Set : " + name.toString())

    println("Before removing element to Name Set : " + name.toString())
    name -= "Sree"
    println("After removing element to Name Set : " + name.toString())

    val uniq = name.union(name2)
    println("Union operation in to sets  : " +uniq.toString())

    val i = name.intersect(name2)
    println("Intersection operation in to sets  : " +i.toString())

    var diff = name2 -- name
    println("Difference beteen to Set name and name2 : " +diff.toString())

    println("Checking Contains in Set name2 : " + name2.contains("Mani"))

    println("Reference class of concatName :  "+ concatName.getClass)
    print("Displaying concatName Set :  ")
    concatName.foreach(y => print(y + "   "))
    println();

  }

}
