package Day6Handson.Ass

import java.util.Scanner

object Factorial {

  var factorial = (number:Int) =>
  {var a=1
    for(x <- 1 to number ){
      a = a*x
    }
    a
  }

  def result(number:Int,fact:((Int)=>Int)):Int =    fact(number)


  def main(args: Array[String]): Unit = {

    val s = new Scanner(System.in)
    println("Enter the factorial Number ")
    val a:Int = s.nextInt()
    println("Result = "+result(a,factorial))
  }
}
