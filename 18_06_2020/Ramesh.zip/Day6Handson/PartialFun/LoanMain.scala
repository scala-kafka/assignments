package Day6Handson.PartialFun

object LoanMain {
  def main(args: Array[String]): Unit = {

    println("Total Interest for Car Loan")
    var carLoan:CarLoan = new CarLoan
    carLoan.print(10,1500000,24)

    println("Total Interest for Home Loan")
    var homeLoan:HomeLoan = new HomeLoan
    homeLoan.print(2541000,36)

  }

}
