package Day6Handson.PartialFun

class Loan {

  def CalculateInterest(percentage:Double,amount:Double,month:Int): Double = {
    var pnr = percentage*amount*month
    var dena = 100*12
    var interest = pnr/dena
    interest
  }

}
