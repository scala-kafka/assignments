package Day6Handson.PartialFun

class CarLoan extends Loan {

  var interest = super.CalculateInterest _

  def print(percentage:Double,amount:Double,month:Int): Unit ={
    println("Interest : " + interest(percentage,amount,month) )
  }
}
