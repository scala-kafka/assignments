package Day6Handson.PartialFun

class HomeLoan extends Loan {

  var interest = super.CalculateInterest (14.1,_:Double,_:Int)

  def print(amount:Double,month:Int): Unit ={
    println("Interest : " + interest(amount,month))
  }
}

