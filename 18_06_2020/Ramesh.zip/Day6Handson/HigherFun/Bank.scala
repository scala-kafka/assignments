/*
package Day6Handson.HigherFun

import java.util.Scanner

object Bank {

  var withDraw = (balance:Double,amount:Double) => balance-amount
  var depsoit = (balance:Double,amount:Double) => balance+amount

  def transfer(balance:Double,amount:Double,tran:((Double,Double) => Double)){
   tran(balance,amount)
  }

  def main(args: Array[String]): Unit = {

    /*println("For withDraw ")
    transfer(24587,2500,withDraw)

    println("For deposit ")
    transfer(21400,3400,depsoit)*/
    var balance:Double = 21400
    val ip:Scanner = new Scanner(System.in)
    println("Enter the amount to Withdraw ")
    var amount = ip.nextDouble()
    balance:Double = transfer(balance,amount,withDraw)
    println("Balance After Withdraw = "+ balance)

    println("Enter the amount to Depsoit ")
    amount = ip.nextDouble()
    balance:Double= transfer(balance,amount,depsoit)
    println("Balance After Depsoit = "+ balance)


  }
}
*/
