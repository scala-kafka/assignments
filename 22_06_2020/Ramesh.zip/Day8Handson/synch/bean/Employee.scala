package Day8Handson.synch.bean

case class Employee(eId:Int,eName:String)