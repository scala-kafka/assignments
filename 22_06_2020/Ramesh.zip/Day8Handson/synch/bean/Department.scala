package Day8Handson.synch.bean

case class Department(dId:Int,dName:String)