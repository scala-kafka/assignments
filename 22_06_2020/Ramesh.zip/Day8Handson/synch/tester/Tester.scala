package Day8Handson.synch.tester

import Day8Handson.synch.bean.{Department, Employee}
import Day8Handson.synch.service.EmployeeService


object Tester {
  var empService:EmployeeService =  new EmployeeService();
  def main(args: Array[String]): Unit = {
    println("Started with the Process");
    println("=========================");
    var dList:List[Department] = List(Department(1001,"Java"),Department(1002,"DB2"),
      Department(1003,"Spark"))
    var eList:List[Employee] = List(Employee(1,"Karthy"),Employee(2,"Keerthu"),
      Employee(3,"Ram"),Employee(4,"Vami"))

     empService.createEmployee(eList);
     empService.createDepartment(dList);
    
    println("Process Completed");
                                                                                       
  }
}
