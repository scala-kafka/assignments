package Day8Handson.synch.service

import Day8Handson.synch.bean.Department
import Day8Handson.synch.bean.Employee
import Day8Handson.synch.dao.EmployeeDAO

class EmployeeService {
  var empDAO:EmployeeDAO  = new EmployeeDAO();
  def createEmployee(eList:List[Employee])={
    var count:Int=0;
    count=empDAO.createEmployee(eList);
    count
  }
  
  def createDepartment(dList:List[Department]){
    var count:Int=0;
    count=empDAO.createDepartment(dList);
    count;
  }
  
}