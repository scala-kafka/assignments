package Day8Handson.synch.dao

import Day8Handson.synch.bean.Department
import Day8Handson.synch.bean.Employee

class EmployeeDAO {
  
  def createEmployee(eList:List[Employee])={
    var count:Int=0;
    for(itr<-eList){
      count+=1;
      Thread.sleep(3000);
      println("Employee Created by: "+Thread.currentThread().getName);
    }
    count
  }
  
  def createDepartment(dList:List[Department])={
    var count:Int=0;
    for(itr<-dList){
      count+=1;
      Thread.sleep(5000);
      println("Department Created by: "+Thread.currentThread().getName);
    }
    count;
  }
  
}