package Day8Handson.Future

import scala.concurrent.{Future}
import scala.concurrent.ExecutionContext.Implicits.global
import scala.util.{Failure, Success}
import scala.util.Random

object FutureDemo3 extends App {

  println("starting calculation ...")
  val f = Future {
    Thread.sleep(Random.nextInt(5000))
    4+2
  }
  println("before onComplete")
  f.onComplete {
    case Success(value) => println(s"Got the callback, meaning = $value")
    case Failure(e) => e.printStackTrace
  }
  println("A ..."); Thread.sleep(2000)
  println("B ..."); Thread.sleep(2000)
  println("C ..."); Thread.sleep(2000)
  Thread.sleep(10000)

}
