package Day8Handson.Future

import scala.concurrent.{Await, Future}
import scala.concurrent.duration._
import scala.concurrent.ExecutionContext.Implicits.global

object FutureDemo1 extends App {

  implicit val baseTime = System.currentTimeMillis

  val f = Future {
    Thread.sleep(5000)
    1 + 1
  }

  val result = Await.result(f, 7 second)
  println(result)
  Thread.sleep(10000)

}
