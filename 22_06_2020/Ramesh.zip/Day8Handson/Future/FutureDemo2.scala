package Day8Handson.Future

import scala.concurrent.{Future}
import scala.concurrent.ExecutionContext.Implicits.global
import scala.util.{Failure, Success}
import scala.util.Random

import scala.concurrent.duration.Duration
import scala.concurrent.{Await, Future}
import scala.concurrent.ExecutionContext.Implicits.global

object FutureDemo2 extends App {
  val f: Future[Int] = Future(0)
  val f2: Future[Unit] = f.map { x =>
    Thread.sleep(10000)
    println("The program waited patiently for this callback to finish.")
  }
  println("F is completed successfully")
  println(Await.ready(f2, Duration.Inf))
  println("F2 is completed successfully")

}
