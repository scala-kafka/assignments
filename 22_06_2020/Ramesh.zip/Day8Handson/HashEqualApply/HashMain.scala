package Day8Handson.HashEqualApply

object HashMain {
  def main(args: Array[String]): Unit = {

    val emp1:Employee = Employee(101,"Radha")
    val emp2:Employee = Employee(101,"Radha")
    val emp3:Employee = Employee(102,"Radha")

    println(emp1 == emp2)
    println(s"HashCode : emp1 = :${emp1.hashCode()} emp2 = ${emp2.hashCode()}")
    println(emp1.equals(emp2))

    println(emp1 == emp3)
    println(s"HashCode : emp1 = :${emp1.hashCode()} emp3 = ${emp3.hashCode()}")
    println(emp1.equals(emp3))

    val name1:String = "Karthy"
    val name2:String = "Karthy"
    println(name1 == name2)
    println(s"HashCode : name1 = :${name1.hashCode} name2 = ${name2.hashCode}")
    println(name1.equals(name2))
  }
}
