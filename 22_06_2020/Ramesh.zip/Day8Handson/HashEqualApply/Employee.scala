package Day8Handson.HashEqualApply

import scala.util.Random

class Employee {
  var eno:Int = _
  var eName:String = _
  def this(eno:Int,eName:String){
    this()
    this.eno = eno
    this.eName= eName
  }

  override def hashCode(): Int = Random.nextInt(45701)

  override def equals(obj: Any): Boolean = {
    var flag = true

    if(obj.isInstanceOf[Employee]){
      val emp:Employee = obj.asInstanceOf[Employee]
      if(eno != emp.eno){
        flag = false
      }else if(!eName.equals(emp.eName)){
        flag = false
      }
    }
    else{
      flag = false
    }
    flag
  }


}

object Employee {

  def apply(eno: Int, eName: String): Employee = new Employee(eno, eName)


}
