package Day8Handson.CaseClass

object caseClassDemo extends App {

  val emp1:Employee = Employee(101,"Radha")
  val emp2:Employee = Employee(101,"Radha")
  val emp3:Employee = Employee(102,"Radha")

  println(emp1 == emp2)
  println(s"HashCode : emp1 = :${emp1.hashCode()} emp2 = ${emp2.hashCode()}")
  println(emp1.equals(emp2))

  println(emp1 == emp3)
  println(s"HashCode : emp1 = :${emp1.hashCode()} emp3 = ${emp3.hashCode()}")
  println(emp1.equals(emp3))

}
