package Day8Handson.CaseClass

case class Employee(eno:Int,eName:String)
