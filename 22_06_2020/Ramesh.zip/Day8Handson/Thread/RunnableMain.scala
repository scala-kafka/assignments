package Day8Handson.Thread

class Calculation extends Runnable{
  override def run() = {
    println("I am running using Runnable")
    println("Thread name : " +Thread.currentThread().getName)
    add(10,30)
  }

  def add(a:Int,b:Int):Unit = {
    println("Thread name : " +Thread.currentThread().getName)
  }

  def mul(a:Int,b:Int):Unit = {
    println("Thread name : " +Thread.currentThread().getName)
  }
}

object RunnableMain extends App {
  println("Main = "+ Thread.currentThread().getName)

  var mr:Calculation = new Calculation;
  var t:Thread = new Thread(mr)
  t.setName("add")
  t.start()
  mr.add(10,30)
  mr.mul(14,13)
  Thread.sleep(2000)



}
