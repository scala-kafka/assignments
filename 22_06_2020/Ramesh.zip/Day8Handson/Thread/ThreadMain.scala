package Day8Handson.Thread

class Calculate extends Thread{
  override def run() = {
    println("I am running using Runnable")
    println("Thread name : " +Thread.currentThread().getName)
    if(Thread.currentThread().getName.equals("add"))
      add(10,30)
    else
      mul(14,24)
  }

  def add(a:Int,b:Int):Unit = {
    println("Thread name : " +Thread.currentThread().getName)
  }

  def mul(a:Int,b:Int):Unit = {
    println("Thread name : " +Thread.currentThread().getName)
  }
}

object ThreadMain extends App {
  println("Main = "+ Thread.currentThread().getName)

  var t:Thread = new Thread(new Calculate)
  Thread.sleep(10000)

  t.setName("add")
  t.start()
}
