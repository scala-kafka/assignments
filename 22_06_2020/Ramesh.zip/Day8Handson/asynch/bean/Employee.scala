package Day8Handson.asynch.bean

case class Employee(eId:Int,eName:String)