package Day8Handson.asynch.bean

case class Department(dId:Int,dName:String)