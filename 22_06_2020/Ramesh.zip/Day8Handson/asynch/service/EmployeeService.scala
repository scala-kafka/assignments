package Day8Handson.asynch.service

import Day8Handson.asynch.bean.{Department, Employee}
import Day8Handson.asynch.dao.EmployeeDAO

import scala.concurrent.Future
import scala.concurrent.ExecutionContext.Implicits.global


class EmployeeService {
  var empDAO:EmployeeDAO  = new EmployeeDAO();
  def createEmployee(eList:List[Employee]):Future[Int]={
    var count:Future[Int]= Future{0};
    count=empDAO.createEmployee(eList);
    count
  }
  
  def createDepartment(dList:List[Department]):Future[Int]={
    var count:Future[Int]= Future{0};
    count=empDAO.createDepartment(dList);
    count;
  }
  
}