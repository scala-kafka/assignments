package Day8Handson.asynch.tester



import Day8Handson.asynch.bean.{Department, Employee}
import Day8Handson.asynch.service.EmployeeService

import scala.concurrent.Await
import scala.concurrent.duration._
import scala.concurrent.Future
import scala.util.{Failure, Success}
import scala.concurrent.ExecutionContext.Implicits.global

object Tester3 {
  var empService:EmployeeService =  new EmployeeService();
  def main(args: Array[String]): Unit = {
    println("Started with the Process");
    println("=========================");
    var dList:List[Department] = List(Department(1001,"Java"),Department(1002,"DB2"),
      Department(1003,"Spark"))
    var eList:List[Employee] = List(Employee(1,"Karthy"),Employee(2,"Keerthu"),
      Employee(3,"Ram"),Employee(4,"Vami"))
     var empCount:Future[Int]= empService.createEmployee(eList);
     var deptCount:Future[Int]=empService.createDepartment(dList);

    var empDeptCountCombined:Future[String]= deptCount.zipWith(empCount)(
                                                        (redeemedDept,redeemedEmployee)=>
                                                        "Dept Created: "+redeemedDept
                                                        +", Employee created: "+redeemedEmployee
                                                      )
     empDeptCountCombined.onComplete{
         case Success(x)=>println(s"Redeemed Result: ${x}");
         case Failure(f)=>println(s"Failure: ${f}")
         println("Click any key to terminate program");
     };


     
     println("After Call Back method");
     println("Press Any key to Stop")
     println("=====================")
     
     
     
     System.in.read()
     //Thread.sleep(150000)                                                                                    
  }
}