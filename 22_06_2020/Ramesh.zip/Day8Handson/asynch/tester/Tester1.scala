package Day8Handson.asynch.tester

import Day8Handson.asynch.bean.{Department, Employee}
import Day8Handson.asynch.service.EmployeeService

import scala.concurrent.{Await, Future}
import scala.concurrent.ExecutionContext.Implicits.global
import scala.concurrent.duration.Duration


object Tester1 {
  var empService:EmployeeService =  new EmployeeService();
  def main(args: Array[String]): Unit = {
    println("Started with the Process");
    println("=========================");
    var dList:List[Department] = List(Department(1001,"Java"),Department(1002,"DB2"),
      Department(1003,"Spark"))
    var eList:List[Employee] = List(Employee(1,"Karthy"),Employee(2,"Keerthu"),
      Employee(3,"Ram"),Employee(4,"Vami"))

    var empCount:Future[Int]= empService.createEmployee(eList);
     var deptCount:Future[Int]=empService.createDepartment(dList);


     var v1:Int= Await.result(empCount,Duration("30 second"));
     var v2:Int= Await.result(deptCount,Duration("20 second"));

    //Await.ready(empCount,Duration("6 second"))

     println("Process Completed: "+(v1+v2));
                                                                                       
  }
}
