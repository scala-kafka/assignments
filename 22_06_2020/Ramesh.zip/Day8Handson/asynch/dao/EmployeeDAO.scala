package Day8Handson.asynch.dao

import Day8Handson.asynch.bean.{Department, Employee}

import scala.concurrent.Future
import scala.concurrent.ExecutionContext.Implicits.global

class EmployeeDAO {
  def createEmployee(eList:List[Employee]):Future[Int]=Future{
  var count:Int=0;
  for(itr<-eList){
  count+=1;
  Thread.sleep(6000);
  println("Employee Created by: ["+Thread.currentThread().getName+"]");
}
  count
}

  def createDepartment(dList:List[Department]):Future[Int]=Future{
  var count:Int=0;
  for(itr<-dList){
  count+=1;
  Thread.sleep(3000);
  println("Department Created by: ["+Thread.currentThread().getName+"]");
}
  count;
}

}
